"use client"

import { useMemo, useState } from "react"
import { Star } from "lucide-react"

type Distribution = Record<number, number>

const seedData: Distribution = { 5: 142, 4: 63, 3: 18, 2: 5, 1: 3 }

export function Feedback() {
  const [distribution, setDistribution] = useState<Distribution>(seedData)
  const [hover, setHover] = useState(0)
  const [selected, setSelected] = useState(0)
  const [submitted, setSubmitted] = useState(false)

  const total = useMemo(
    () => Object.values(distribution).reduce((a, b) => a + b, 0),
    [distribution],
  )

  const average = useMemo(() => {
    if (total === 0) return 0
    const sum = Object.entries(distribution).reduce(
      (acc, [star, count]) => acc + Number(star) * count,
      0,
    )
    return sum / total
  }, [distribution, total])

  function submit() {
    if (selected === 0) return
    setDistribution((prev) => ({ ...prev, [selected]: (prev[selected] ?? 0) + 1 }))
    setSubmitted(true)
  }

  return (
    <section id="feedback" className="bg-secondary py-16 md:py-24">
      <div className="mx-auto max-w-5xl px-4 md:px-6">
        <div className="mb-10 text-center">
          <span className="rounded-full bg-accent px-4 py-1.5 text-xs font-bold uppercase tracking-[0.2em] text-accent-foreground">
            Your opinion matters
          </span>
          <h2 className="mt-4 text-balance font-heading text-4xl font-black uppercase tracking-tight text-foreground md:text-5xl">
            Rate the Recipes
          </h2>
          <p className="mx-auto mt-3 max-w-lg text-pretty leading-relaxed text-muted-foreground">
            Cooked something from Zest Forward? Tap the stars and let us know how
            it turned out.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {/* Rating input card */}
          <div className="flex flex-col items-center justify-center gap-6 rounded-3xl border border-border bg-card p-8 text-center shadow-sm">
            {submitted ? (
              <div className="flex flex-col items-center gap-3">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary">
                  <Star className="h-8 w-8 fill-primary-foreground text-primary-foreground" />
                </div>
                <h3 className="font-heading text-2xl font-black uppercase text-foreground">
                  Thank you!
                </h3>
                <p className="text-muted-foreground">
                  You rated us {selected} {selected === 1 ? "star" : "stars"}.
                </p>
                <button
                  onClick={() => {
                    setSubmitted(false)
                    setSelected(0)
                    setHover(0)
                  }}
                  className="mt-2 rounded-full border-2 border-primary px-5 py-2 text-sm font-bold text-primary transition-all hover:bg-primary hover:text-primary-foreground"
                >
                  Rate again
                </button>
              </div>
            ) : (
              <>
                <h3 className="font-heading text-xl font-bold uppercase tracking-wide text-foreground">
                  Choose your rating
                </h3>
                <div className="flex items-center gap-2" role="radiogroup" aria-label="Star rating">
                  {[1, 2, 3, 4, 5].map((value) => {
                    const active = value <= (hover || selected)
                    return (
                      <button
                        key={value}
                        type="button"
                        role="radio"
                        aria-checked={selected === value}
                        aria-label={`${value} ${value === 1 ? "star" : "stars"}`}
                        onMouseEnter={() => setHover(value)}
                        onMouseLeave={() => setHover(0)}
                        onClick={() => setSelected(value)}
                        className="transition-transform hover:scale-125"
                      >
                        <Star
                          className={`h-9 w-9 transition-colors ${
                            active
                              ? "fill-accent text-accent"
                              : "fill-muted text-muted-foreground/40"
                          }`}
                        />
                      </button>
                    )
                  })}
                </div>
                <p className="h-5 text-sm font-semibold text-muted-foreground">
                  {selected > 0 ? `${selected} of 5 stars selected` : "Tap a star"}
                </p>
                <button
                  onClick={submit}
                  disabled={selected === 0}
                  className="rounded-full bg-primary px-8 py-3 font-bold text-primary-foreground shadow-md transition-all hover:scale-105 hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:scale-100"
                >
                  Submit Feedback
                </button>
              </>
            )}
          </div>

          {/* Stats / distribution card */}
          <div className="rounded-3xl border border-border bg-card p-8 shadow-sm">
            <div className="mb-6 flex items-end justify-between gap-4 border-b border-border pb-5">
              <div>
                <p className="font-heading text-5xl font-black text-foreground">
                  {average.toFixed(1)}
                </p>
                <div className="mt-1 flex items-center gap-0.5" aria-hidden="true">
                  {[1, 2, 3, 4, 5].map((v) => (
                    <Star
                      key={v}
                      className={`h-4 w-4 ${
                        v <= Math.round(average)
                          ? "fill-accent text-accent"
                          : "fill-muted text-muted-foreground/40"
                      }`}
                    />
                  ))}
                </div>
              </div>
              <div className="text-right">
                <p className="font-heading text-3xl font-black text-primary">{total}</p>
                <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">
                  Total feedbacks
                </p>
              </div>
            </div>

            <ul className="flex flex-col gap-3">
              {[5, 4, 3, 2, 1].map((star) => {
                const count = distribution[star] ?? 0
                const pct = total > 0 ? (count / total) * 100 : 0
                return (
                  <li key={star} className="flex items-center gap-3">
                    <span className="flex w-12 shrink-0 items-center gap-1 text-sm font-bold text-foreground">
                      {star}
                      <Star className="h-3.5 w-3.5 fill-accent text-accent" />
                    </span>
                    <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-muted">
                      <div
                        className="h-full rounded-full bg-primary transition-all duration-500"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                    <span className="w-10 shrink-0 text-right text-sm font-semibold text-muted-foreground">
                      {count}
                    </span>
                  </li>
                )
              })}
            </ul>
            <p className="mt-5 text-center text-xs text-muted-foreground">
              {distribution[5] ?? 0} people gave a perfect 5-star rating.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
