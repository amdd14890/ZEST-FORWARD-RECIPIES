import Image from "next/image"

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-background">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-4 px-4 py-10 text-center md:px-6">
        <div className="flex items-center gap-3">
          <Image
            src="/images/logo.png"
            alt="ZEST FORWARD Recipes logo"
            width={40}
            height={40}
            className="h-10 w-10 rounded-full object-contain"
          />
          <span className="font-heading text-lg font-black uppercase tracking-tight text-primary">
            Zest Forward Recipes
          </span>
        </div>
        <p className="max-w-md text-sm leading-relaxed text-muted-foreground">
          Cooking the world&apos;s rarest comfort food, one bold recipe at a time.
        </p>
        <p className="text-xs text-muted-foreground">
          &copy; {new Date().getFullYear()} Zest Forward Recipes. Made with zest.
        </p>
      </div>
    </footer>
  )
}
