import Image from "next/image"
import type { Recipe } from "@/lib/recipes"

export function RecipeCard({ recipe, reversed }: { recipe: Recipe; reversed?: boolean }) {
  return (
    <article className="overflow-hidden rounded-3xl border border-border bg-card shadow-sm transition-all hover:shadow-xl">
      <div className={`grid gap-0 lg:grid-cols-2 ${reversed ? "lg:[direction:rtl]" : ""}`}>
        <div className="relative aspect-[4/3] overflow-hidden lg:aspect-auto lg:[direction:ltr]">
          <Image
            src={recipe.image || "/placeholder.svg"}
            alt={`${recipe.title} — ${recipe.description.slice(0, 60)}`}
            fill
            className="object-cover transition-transform duration-700 hover:scale-105"
          />
          <span className="absolute left-4 top-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary font-heading text-xl font-black text-primary-foreground shadow-md">
            {recipe.number}
          </span>
        </div>

        <div className="flex flex-col gap-5 p-6 md:p-8 lg:[direction:ltr]">
          <div>
            <span className="text-xs font-bold uppercase tracking-[0.2em] text-primary">
              {recipe.origin}
            </span>
            <h3 className="mt-1 text-balance font-heading text-3xl font-black uppercase tracking-tight text-foreground md:text-4xl">
              {recipe.title}
            </h3>
          </div>

          <p className="text-pretty leading-relaxed text-muted-foreground">{recipe.description}</p>

          <div className="rounded-2xl bg-secondary p-4">
            <p className="text-pretty text-sm font-medium italic leading-relaxed text-secondary-foreground">
              {recipe.intro}
            </p>
          </div>

          <div>
            <h4 className="mb-2 font-heading text-sm font-bold uppercase tracking-wide text-foreground">
              Ingredients
            </h4>
            <ul className="grid gap-2 sm:grid-cols-2">
              {recipe.ingredients.map((ing) => (
                <li key={ing} className="flex items-start gap-2 text-sm leading-relaxed text-muted-foreground">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" aria-hidden="true" />
                  {ing}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="mb-3 font-heading text-sm font-bold uppercase tracking-wide text-foreground">
              Step-by-Step
            </h4>
            <ol className="flex flex-col gap-4">
              {recipe.steps.map((step, i) => (
                <li key={step.title} className="flex gap-3">
                  <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-accent text-sm font-bold text-accent-foreground">
                    {i + 1}
                  </span>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-bold text-foreground">{step.title}</span>
                      {step.time && (
                        <span className="rounded-full bg-muted px-2 py-0.5 text-xs font-semibold text-muted-foreground">
                          {step.time}
                        </span>
                      )}
                    </div>
                    <p className="mt-0.5 text-sm leading-relaxed text-muted-foreground">{step.detail}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>

          {recipe.tip && (
            <div className="rounded-2xl border-l-4 border-primary bg-secondary/60 p-4">
              <p className="font-heading text-sm font-bold uppercase tracking-wide text-primary">
                {recipe.tip.title}
              </p>
              <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{recipe.tip.detail}</p>
            </div>
          )}
        </div>
      </div>
    </article>
  )
}
