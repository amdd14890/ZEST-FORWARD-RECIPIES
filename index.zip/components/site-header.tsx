import Image from "next/image"

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3 md:px-6">
        <a href="#top" className="flex items-center gap-3">
          <Image
            src="/images/logo.png"
            alt="ZEST FORWARD Recipes logo"
            width={48}
            height={48}
            className="h-11 w-11 rounded-full object-contain"
            priority
          />
          <div className="leading-none">
            <span className="block font-heading text-lg font-black uppercase tracking-tight text-primary md:text-xl">
              Zest Forward
            </span>
            <span className="block text-xs font-semibold uppercase tracking-[0.3em] text-muted-foreground">
              Recipes
            </span>
          </div>
        </a>
        <nav className="hidden items-center gap-8 text-sm font-semibold md:flex">
          <a href="#recipes" className="text-foreground transition-colors hover:text-primary">
            Recipes
          </a>
          <a href="#feedback" className="text-foreground transition-colors hover:text-primary">
            Feedback
          </a>
        </nav>
        <a
          href="#recipes"
          className="rounded-full bg-primary px-5 py-2 text-sm font-bold text-primary-foreground shadow-sm transition-all hover:scale-105 hover:bg-primary/90"
        >
          Start Cooking
        </a>
      </div>
    </header>
  )
}
