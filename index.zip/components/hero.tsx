import Image from "next/image"

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden bg-secondary">
      <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-16 md:grid-cols-2 md:px-6 md:py-24">
        <div className="flex flex-col items-start gap-6">
          <span className="rounded-full bg-accent px-4 py-1.5 text-xs font-bold uppercase tracking-[0.2em] text-accent-foreground">
            Rare recipes, bold flavor
          </span>
          <h1 className="text-balance font-heading text-5xl font-black uppercase leading-[0.95] tracking-tight text-foreground md:text-7xl">
            Zest <span className="text-primary">Forward</span> Recipes
          </h1>
          <p className="max-w-md text-pretty text-lg leading-relaxed text-muted-foreground">
            We hunt down the world&apos;s rarest, most comforting dishes and break them
            down step by step. Crispy, cheesy, savory and unforgettable — these are
            the recipes worth cooking forward.
          </p>
          <div className="flex flex-wrap items-center gap-3">
            <a
              href="#recipes"
              className="rounded-full bg-primary px-7 py-3 font-bold text-primary-foreground shadow-md transition-all hover:scale-105 hover:bg-primary/90"
            >
              Explore Recipes
            </a>
            <a
              href="#feedback"
              className="rounded-full border-2 border-primary px-7 py-3 font-bold text-primary transition-all hover:scale-105 hover:bg-primary hover:text-primary-foreground"
            >
              Leave Feedback
            </a>
          </div>
        </div>
        <div className="relative">
          <div className="overflow-hidden rounded-3xl border-4 border-background shadow-2xl">
            <Image
              src="/images/hero.png"
              alt="Fresh cooking ingredients including avocados, cornmeal, herbs and cheese on a light green surface"
              width={800}
              height={800}
              className="h-full w-full object-cover transition-transform duration-700 hover:scale-105"
              priority
            />
          </div>
          <div className="absolute -bottom-5 -left-5 hidden rounded-2xl bg-accent px-6 py-4 shadow-lg md:block">
            <p className="font-heading text-3xl font-black text-accent-foreground">2</p>
            <p className="text-xs font-bold uppercase tracking-wide text-accent-foreground">
              Hand-picked recipes
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
