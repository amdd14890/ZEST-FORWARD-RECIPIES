import { SiteHeader } from "@/components/site-header"
import { Hero } from "@/components/hero"
import { RecipeCard } from "@/components/recipe-card"
import { Feedback } from "@/components/feedback"
import { SiteFooter } from "@/components/site-footer"
import { recipes } from "@/lib/recipes"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <SiteHeader />
      <Hero />

      <section id="recipes" className="mx-auto max-w-6xl px-4 py-16 md:px-6 md:py-24">
        <div className="mb-10 text-center">
          <span className="rounded-full bg-accent px-4 py-1.5 text-xs font-bold uppercase tracking-[0.2em] text-accent-foreground">
            The collection
          </span>
          <h2 className="mt-4 text-balance font-heading text-4xl font-black uppercase tracking-tight text-foreground md:text-5xl">
            Recipes Worth the Effort
          </h2>
          <p className="mx-auto mt-3 max-w-lg text-pretty leading-relaxed text-muted-foreground">
            Two rare dishes, fully broken down so you can nail them on the first try.
          </p>
        </div>

        <div className="flex flex-col gap-10">
          {recipes.map((recipe, i) => (
            <RecipeCard key={recipe.id} recipe={recipe} reversed={i % 2 === 1} />
          ))}
        </div>
      </section>

      <Feedback />
      <SiteFooter />
    </main>
  )
}
