export type Recipe = {
  id: string
  number: number
  title: string
  origin: string
  image: string
  description: string
  intro: string
  ingredients: string[]
  steps: { title: string; detail: string; time?: string }[]
  tip?: { title: string; detail: string }
}

export const recipes: Recipe[] = [
  {
    id: "georgian-chvishtari",
    number: 1,
    title: "Georgian Chvishtari",
    origin: "Svaneti, Georgia",
    image: "/images/chvishtari.png",
    description:
      "A rare, comforting street food from the Svaneti region of Georgia. Unlike American cornbread, it uses white cornmeal and a massive amount of traditional Sulguni cheese to create an ultra-stretchy, crispy-crusted cake.",
    intro:
      "Trust me on this one — the first time you pull one of these apart and watch the cheese stretch a full foot in the air, you'll understand why I keep a bag of white cornmeal in my pantry at all times. You need to try it.",
    ingredients: [
      "2 cups white cornmeal (fine grind)",
      "1.5 cups Sulguni cheese (or a 50/50 mix of low-moisture Mozzarella and Feta), grated",
      "1 egg",
      "1/2 cup warm water (or milk)",
      "1 tbsp melted butter",
      "Vegetable oil for shallow frying",
    ],
    steps: [
      {
        title: "Mix the Dough",
        detail:
          "In a large bowl, combine the white cornmeal and grated cheese. Add the egg and melted butter.",
      },
      {
        title: "Hydrate",
        detail:
          "Slowly pour in the warm water or milk a little at a time, kneading with your hands until a firm, pliable dough forms. It should hold its shape when squeezed.",
      },
      {
        title: "Shape",
        detail:
          "Divide the dough into small, oval-shaped patties (about the size of your palm) and flatten them slightly to about 1/2-inch thickness.",
      },
      {
        title: "Fry",
        detail:
          "Heat a generous amount of vegetable oil in a skillet over medium heat. Place the cakes in the oil.",
      },
      {
        title: "Crisp",
        detail:
          "Fry for 5–6 minutes on each side until the crust is deeply golden brown and the cheese inside is completely melted and stretchy. Serve hot immediately.",
        time: "5–6 mins / side",
      },
    ],
  },
  {
    id: "oaxacan-chochoyotes",
    number: 2,
    title: "Oaxacan Chochoyotes",
    origin: "Oaxaca, Mexico",
    image: "/images/chochoyotes.png",
    description:
      "Traditional Mexican corn masa dumplings in black bean mole. They feature a signature dimple pressed into the center, which acts like a tiny bowl to capture rich, savory sauces. Common in Oaxacan home kitchens, but rarely found on restaurant menus outside of Mexico.",
    intro:
      "These little dumplings are pure home-kitchen magic — humble, deeply savory, and almost impossible to find in a restaurant. Make them once and they'll become your go-to way to turn a pot of beans into something special.",
    ingredients: [
      "1.5 cups Masa Harina (corn flour)",
      "1 cup warm water",
      "2 tbsp lard (or vegetable shortening/substitute)",
      "1/2 tsp salt",
      "1 tsp finely chopped fresh epazote (or cilantro)",
      "3 cups prepared black bean soup or diluted Mole sauce",
    ],
    steps: [
      {
        title: "Hydrate the Masa",
        time: "5 mins",
        detail:
          "In a medium bowl, mix the masa harina and salt. Gradually pour in the warm water, mixing with your hands until a smooth, pliable dough forms. If it feels dry or cracks, add water 1 tablespoon at a time.",
      },
      {
        title: "Incorporate Fat and Herbs",
        time: "5 mins",
        detail:
          "Add the lard (or shortening) and chopped epazote/cilantro to the dough. Knead thoroughly for 2 to 3 minutes until the fat is completely absorbed and the dough feels smooth and slightly greasy.",
      },
      {
        title: "Shape the Dumplings",
        time: "10 mins",
        detail:
          "Roll the dough into small balls about the size of a cherry or a small walnut. Press your thumb firmly into the center of each ball to create a deep well or dimple. This shape ensures the dumpling cooks evenly throughout.",
      },
      {
        title: "Poach in Sauce",
        time: "15 mins",
        detail:
          "Bring your black bean soup or mole to a gentle simmer in a wide pot. Carefully drop the dumplings into the simmering liquid one by one. Do not stir immediately, or they might break.",
      },
      {
        title: "Simmer and Serve",
        time: "12 mins",
        detail:
          "Cover the pot and simmer gently for 10 to 12 minutes. The chochoyotes are ready when they float to the surface and are cooked through, absorbing the rich flavors of the dark sauce. Serve hot with a sprinkle of crumbly cotija cheese.",
      },
    ],
    tip: {
      title: "Why the dimple matters",
      detail:
        "The thumbprint isn't just for looks; it reduces the thickness in the center of the dough ball, ensuring the masa cooks through evenly without leaving a raw, gummy core.",
    },
  },
]
